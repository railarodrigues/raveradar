# Validação desta entrega

- Cinco testes automatizados da lógica passaram com Node.js.
- A sintaxe dos módulos da interface e do servidor foi verificada.
- O servidor local respondeu ao HTML, CSS e JavaScript.
- A inspeção visual e os testes ponta a ponta no navegador não foram concluídos: o navegador de testes não estava disponível e seu download foi bloqueado pelo ambiente.

Antes de publicar, conferir manualmente: estilos e busca, favoritos após recarregar, orçamento com duas e quatro pessoas, zero pessoas, checklist após recarregar, exportação e largura de celular.
