# Como explicar o RaveRadar

## Apresentação curta

“Criei um planner de raves para organizar orçamento e preparação do rolê. A interface permite filtrar eventos demonstrativos, selecionar um evento, dividir as despesas do grupo e acompanhar um checklist. Usei HTML, CSS e JavaScript, com dados salvos no navegador. Desenvolvi o projeto com assistência de IA e estou estudando suas partes.”

## O que acontece ao clicar

1. O navegador carrega o HTML, o CSS e o módulo `src/app.js`.
2. O app lê o plano salvo em `localStorage`; `cleanState` recupera apenas dados válidos.
3. `renderEvents` mostra os eventos que combinam com o estilo e o texto da busca.
4. Ao editar o orçamento, o formulário valida os campos e a função `budget` calcula as despesas.
5. Ao marcar um item, a interface atualiza o progresso e salva o novo estado.
6. Exportar gera um arquivo JSON no dispositivo, sem enviar dados a um servidor.

## Perguntas que podem aparecer

**Por que separou a lógica da interface?**
Para testar orçamento e filtros sem precisar abrir o navegador. `core.js` contém as funções; `app.js` conecta essas funções aos botões e campos.

**Tem banco de dados?**
Não. O estado fica no navegador da pessoa, em `localStorage`. É uma escolha simples para esta versão de portfólio e não permite compartilhar o plano automaticamente.

**Os eventos são reais?**
Não, são demonstrações identificadas na interface. Uma agenda real exigiria uma fonte de dados com permissão para uso e tratamento de atualizações.

**O que acontece se alguém digitar zero pessoas?**
O formulário exibe um aviso, não calcula uma divisão inválida e bloqueia a exportação até corrigir os dados.

**Você fez tudo sozinha?**
O projeto foi desenvolvido com assistência de IA. Explique o que você já entende e mostre uma função que estudou ou alterou. O README registra essa assistência.

## Pequenas mudanças para aprender

- Mude os nomes e cores dos eventos em `core.js` e `style.css`.
- Acrescente um item ao checklist. Ajuste também `aria-valuemax` no HTML.
- Altere os valores do exemplo e confira o total manualmente.
- Rode `npm test` e leia o teste de divisão de custos.

## Publicar no GitHub

1. Crie um repositório chamado `rave-radar` na sua conta.
2. Extraia o ZIP e envie o conteúdo da pasta `rave-radar`, preservando `src`, `tests` e `docs`.
3. Use a descrição: “Planner de raves com orçamento por pessoa, checklist e favoritos. HTML, CSS e JavaScript.”
4. Sugestões de tópicos: `javascript`, `frontend`, `rave`, `event-planner`, `portfolio`.
5. Após publicar, abra o README e confira se os arquivos estão na raiz.

Para executar localmente, abra a pasta no terminal e use `npm start`.
